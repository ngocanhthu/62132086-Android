@extends('admin.layouts.master')

@section('title')
    Quản lý cửa hàng
@endsection